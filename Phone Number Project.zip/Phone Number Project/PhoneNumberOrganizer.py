#Tools
#Glob helps search for files for my file list
import glob
#Pandas interacts with CSV dataframes
import pandas as pd
#Pattern searching tool
import re
#Used for copying files
import shutil

fileSaveLocation = r'./Organized PN Folder/'


####    Function to copy file from one place to another with different name
def copyFile(fileName, fileRename):
    shutil.copyfile(fileName, fileRename)


#Open Book1.csv to a dataframe variable
dfBook1 = pd.read_csv(r'./Book1.csv')
print("dfBook1 found and successfully saved.")

#Take information off of Book1.csv (funded customers)
##Information: Borrower and Borrower Phone
###Save the Borrower and Borrower Phone into separate lists with cooresponding indexes

####    Assigns dfBook1's column called Borrower to a separate column
dfBorrower = dfBook1['Borrower']

####    Converts df variable type to a list for the column information
print("\ndfBorrower saved Borrower column")
Borrowerlist = dfBorrower.values.tolist()
print(Borrowerlist)

####    Assigns dfBook1's column called Borrower Phone to a separate column
dfBorrowerPhone = dfBook1['Borrower Phone']

####    Converts df variable type to a list for the column information
print("\ndfBorrowerPhone saved Borrower Phone column")
BorrowerPhonelist = dfBorrowerPhone.values.tolist()
print(BorrowerPhonelist)


#Search for all .csv files in a folder and put them into a list (can choose location)
csv_file_location = (".\Boss Folder\*.csv")
####    or use "C:\AnyLocation\*.csv"

####    Use Glob to search for CSVs in current folder or chosen path.
file_list = [f for f in glob.glob(csv_file_location)]
print("\nFiles in folder:")
print(file_list)
print("")


# Search a file name for a phone number #
##Create a universal phone number format pattern variable
phone_number_format = r'(\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4}|\d{3}[-\.\s]??\d{4})'

#Assign phone number format to pattern variable called r
r = re.compile(phone_number_format)

###Extract phone number from file name using phone number format
for file in file_list:
    print("The file name being searched is called " + '"' + file + '"\n')
    phoneNumber = (r.findall(file))[0]
    
    if r.search(file):
        print("Found this Phone Number: " + str(phoneNumber))
        
        
#####Compare extracted phone number to phone numbers in the BorrowerPhonelist variable (Save file name for later)    
    for phones in BorrowerPhonelist:
        ####    Delete formatting from original Phone Numbers and found phone numbers before if statement
        
        phonesNew = r.findall(phones)[0]
        phonesNew = re.sub(r'[^\w]', '', phonesNew)
        phoneNumber = re.sub(r'[^\w]', '', phoneNumber)

        if phonesNew == phoneNumber:
            ####    Save File in fileSaveLocation variable location
            print("The phone number from the title matches a phone number from the " + str(file) + " file.")
            
            fileRename = fileSaveLocation + phonesNew + ".csv"
            copyFile(file, fileRename)
        