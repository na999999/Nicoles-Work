#Tools
#Glob helps search for files for my file list
import glob
#Pandas interacts with CSV dataframes
import pandas as pd
#Pattern searching tool
import re


#Function to search for file or make folder for phone number results
#Incomplete and shrunk
def moveRenameFile(files):
    filename = (phone_number + "_Copied" + ".csv")

    try:
        f = open(filename, 'w')
        f.write()
    # Do something with the file
    except IOError:
        print("Creating File: " + filename)
        f = open(filename, "x")
        
    finally:
        f.close()
        

#Variables for Later Use
csv_file_location = (".\*.csv")
# or use "C:\AnyLocation\*.csv"

phone_number = None
phone_number_format = r'(\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4}|\d{3}[-\.\s]??\d{4})'



#Use Glob to search for CSVs in current folder or chosen path.
file_list = [f for f in glob.glob(csv_file_location)]

#Prints files in file_list into console to see if it works
print (file_list)


#Look through each file for phone numbers
    #Import csv to dataframe variable for each file in file list
for files in file_list:
    df = pd.read_csv(files)
    
    #print information from dataframe to see if it works
    print(df)
    
    DFlist = df.values.tolist()
    
    print(DFlist)
    
    
    #Assign phone number format to pattern variable called r
    r = re.compile(phone_number_format)
    
    
    #DFvalue = df.search(r)
    #print(DFvalue)
    
    #results = r.findall(DFvalue)
    
    #phoneNumbers = []
    #for phone in results:
        #phoneNumbers = (str(phone) + "\n")      
      
        
      
        
      
        
    #Search files for phone number    
    if filter(r.match, DFlist):
        #moveRenameFile(files)
        phone_number = filter(r.match, DFlist)
        print(phone_number)
        print("worked")
    else:
        print("No phone numbers in " + files)    
        
        
        

            
