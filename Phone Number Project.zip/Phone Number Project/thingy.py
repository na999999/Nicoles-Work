#Panda is the tool that is imported. It reads data files like .xlsx and .csv
import pandas as pd

#Maybe use these lines later, otherwise skip
    #from pandas import ExcelWriter
    #from pandas import ExcelFile

#Open File, File handling
    #filename is variable assigned to the name of the file that will be used
    #for saving the information collected by the program
filename = "fileword.txt"

    #Error handler: Attempts code. When code does not work because of an error,
    #it tries to do the next section of code listed.
    #In this case it tries to open a file. When it cant open the file because
    #it does not exist, it creates the file for you.
try:
    f = open(filename)
    # Do something with the file
except IOError:
    print("Creating File: " + filename)
    f = open(filename, "x")


#Creates a list variable that holds words to look for.
Dictionary = ["call", "talk", "3"]

#Open Excel file using read_excel command from pandas, then assign to df
df = pd.read_excel(r'testing excel.xlsx')

for word in Dictionary:
    print("Target word: " + word)
    column = df['REGION'].str.contains(word)
    column2 = df['REGION']
    print(column)

f.close()
